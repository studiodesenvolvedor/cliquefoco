# Clique Foco — Firebase gratuito + GitHub Pages

Este pacote já contém a configuração do projeto **sitecliquefoco** e o UID administrativo informado. Não utiliza Python, Cloud Functions, Firebase Storage nem plano Blaze. Os dados usam Cloud Firestore e Firebase Authentication no plano Spark, sujeitos às cotas do Firebase. O vídeo será incorporado por link do YouTube ou Vimeo.

## 1. Publique as regras no Firebase

1. Entre no projeto `sitecliquefoco` no console do Firebase.
2. Abra **Firestore Database → Regras**. Confirme que está no banco `(default)`.
3. Abra o arquivo `firestore.rules` deste pacote em um editor de texto.
4. Copie o conteúdo completo, substitua o conteúdo da aba Regras e clique em **Publicar**.
5. Aguarde a aplicação das regras. Não é necessário criar coleções manualmente.

As regras permitem leitura do conteúdo público, acesso dos clientes somente aos próprios cadastros, consulta da disponibilidade sem dados de contato e administração pelo UID `jLkMt4uhgBU547BXifsKTPyTMh92`.

## 2. Confira o Authentication

Em **Authentication → Método de login**, mantenha ativados **E-mail/senha** e **Anônimo**. O administrador deve usar a conta já criada, cujo UID está acima. Não há senha fixa dentro dos arquivos.

## 3. Envie os arquivos ao GitHub

No repositório do seu site, clique em **Add file → Upload files** e envie estes arquivos na raiz, no mesmo nível:

- `index.html` — página do cliente e painel depois do login;
- `admin.html` — entrada administrativa por e-mail e senha;
- `app.js` — funcionamento das telas;
- `firebase-config.js` — configuração do seu projeto;
- `firebase-service.js` — conexão e operações com o Firebase;
- `foco.html` — redirecionamento para preservar links antigos com esse nome.

Envie os arquivos extraídos, não apenas o ZIP. Confirme em **Commit changes**. Substitua as versões antigas dos arquivos com os mesmos nomes. Os arquivos de instruções e regras podem ficar fora do repositório; as regras só passam a valer quando publicadas no console do Firebase.

A configuração Web do Firebase e o UID são identificadores públicos; o controle de acesso efetivo é feito pelo Authentication e pelas regras. Nunca coloque senha do admin ou chave privada de conta de serviço no repositório.

## 4. Ative o GitHub Pages

Em **Settings → Pages**:

- Source: **Deploy from a branch**;
- Branch: **main**;
- Pasta: **/ (root)**;
- Clique em **Save**.

Aguarde o GitHub mostrar o endereço publicado, normalmente:

`https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`

Para o admin, acrescente `admin.html` a esse endereço. Use sempre o link publicado; abrir os arquivos por duplo clique não executa os módulos corretamente.

## 5. Autorize o domínio

No Firebase, abra **Authentication → Configurações → Domínios autorizados → Adicionar domínio**.

Adicione apenas `SEU-USUARIO.github.io`, sem `https://` e sem o nome do repositório. Se usar um domínio próprio, adicione-o também.

## 6. Teste antes de divulgar

1. Abra a página do cliente em uma janela anônima.
2. Complete o formulário e confirme um horário.
3. Em uma janela normal, abra `admin.html` e entre com o e-mail e a senha da conta administrativa.
4. Confira o cliente no CRM, suas respostas e a reunião.
5. Edite o cadastro ou a situação pelo CRM; a alteração deve aparecer na janela do cliente.
6. No **Editor CMS**, altere um texto e clique em **Salvar e publicar alterações**.
7. Confira a mudança na janela anônima. O Firestore envia as atualizações automaticamente, sem precisar recarregar a página.

Os cadastros são enviados ao concluir o formulário. Os agendamentos só são confirmados após a gravação no Firebase. Rascunhos do CMS ficam locais até clicar em Salvar e publicar. Se outro admin tiver publicado antes, recarregue para receber o conteúdo mais recente antes de editar novamente.

## 7. Adicione o vídeo depois

Enquanto o campo de vídeo estiver vazio, o bloco de vídeo não aparece para os clientes.

Quando o vídeo estiver pronto:

1. Envie-o ao YouTube, com visibilidade **Não listado** e incorporação permitida.
2. Copie o link, por exemplo `https://www.youtube.com/watch?v=XXXXXXXXXXX`.
3. Entre no admin e abra **Editor CMS → Vídeo Principal**.
4. Cole o link e clique em **Salvar e publicar alterações**.

O player aparece dentro da página. O cliente clica para assistir sem precisar abrir o YouTube. Se o proprietário restringir a incorporação, idade ou acesso ao vídeo, o YouTube poderá impedir a reprodução incorporada. O próprio player pode mostrar marca, anúncios ou links do YouTube.

Para trocar a foto do CEO ou a capa do vídeo, cole uma URL HTTPS pública da imagem no campo correspondente. Esta versão não faz upload de imagens ao Firebase Storage.

## Comportamento dos dados

- Clientes são identificados pelo login anônimo persistente do Firebase naquele navegador. Há um formulário por identidade anônima.
- O admin vê todos os cadastros. Cada cliente recebe apenas o próprio cadastro e conteúdo público.
- O atendimento continua acessível ao voltar pelo mesmo navegador. Limpar os dados do navegador, encerrar uma sessão anônima ou usar outro aparelho cria outra identidade e não recupera o cadastro anterior. Acesso individual entre aparelhos exige uma etapa adicional de autenticação do cliente.
- As reservas aceitam terça a sexta, início às 10h, 12h, 14h, 16h, 18h ou 20h, no horário de Fortaleza, com limite de três por dia.
- O admin pode remarcar pelo CRM. O horário antigo é liberado e o novo é reservado na mesma transação.
- O documento de disponibilidade contém apenas horários e identificadores opacos, sem nome, telefone ou e-mail.
- As métricas são contagens de identidades anônimas que visitaram, clicaram no vídeo, iniciaram/concluíram o formulário e agendaram. Clique no vídeo não indica reprodução completa. Novos navegadores podem contar como novos visitantes.
- Dados antigos salvos apenas no navegador pela versão anterior não são migrados automaticamente.
- Mantenha o uso dentro das cotas do plano Spark e acompanhe a aba Uso do Firebase. As cotas não são ilimitadas.

## Se aparecer uma mensagem de erro

| Mensagem / situação | O que conferir |
| --- | --- |
| Acesso bloqueado | Regras publicadas no projeto `sitecliquefoco`, banco `(default)` |
| Método de login indisponível | E-mail/senha e Anônimo ativados |
| Domínio não autorizado | Domínio do GitHub Pages na lista de domínios autorizados |
| Conta não administradora | Login feito com a conta do UID informado |
| Página não carrega | Todos os cinco arquivos enviados na mesma pasta e acesso pelo GitHub Pages |
| Sem conexão / limite de uso | Internet e aba Uso do projeto Firebase |

Os arquivos carregam Firebase, React, Tailwind e imagens externas pela internet. A instalação no projeto real depende da publicação das regras e dos arquivos; o pacote não altera seu Firebase ou GitHub automaticamente.
